import java.util.HashMap;
	import java.util.Map;
public class UniquecharacterinString {
	

	    public static char findFirstUniqueCharacter(String input) {
	        // Create a HashMap to store the character frequency
	        Map<Character, Integer> charFrequency = new HashMap<>();

	        // Count the frequency of each character in the input string
	        for (char c : input.toCharArray()) {
	            charFrequency.put(c, charFrequency.getOrDefault(c, 0) + 1);
	        }

	        // Find the first unique character by iterating through the input string again
	        for (char c : input.toCharArray()) {
	            if (charFrequency.get(c) == 1) {
	                return c;
	            }
	        }

	        // If no unique character is found, return a default value
	        return '\0';
	    }

	    public static void main(String[] args) {
	        String input = "abracadabra";
	        char firstUniqueChar = findFirstUniqueCharacter(input);
	        
	        if (firstUniqueChar != '\0') {
	            System.out.println("First unique character: " + firstUniqueChar);
	        } else {
	            System.out.println("No unique character found.");
	        }
	    }
	}


