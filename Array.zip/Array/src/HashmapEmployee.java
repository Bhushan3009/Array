import java.util.HashMap;
	import java.util.Map;
public class HashmapEmployee {
	

	
	    public static void main(String[] args) {
	        // Create a HashMap to store employee details
	        Map<Integer, String> employeeMap = new HashMap<>();

	        // Add employee details to the HashMap
	        employeeMap.put(1, "John Doe");
	        employeeMap.put(2, "Jane Smith");
	        employeeMap.put(3, "Michael Johnson");
	        employeeMap.put(4, "Emily Davis");
	        employeeMap.put(5, "Robert Wilson");

	        // Display keys separately
	        System.out.println("Employee IDs:");
	        for (int empId : employeeMap.keySet()) {
	            System.out.println(empId);
	        }

	        // Display values separately
	        System.out.println("\nEmployee Names:");
	        for (String empName : employeeMap.values()) {
	            System.out.println(empName);
	        }
	    }
	}


