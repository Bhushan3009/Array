package Arrayprog;

public class B {
	public static int fetchLastDigit(int num) {
        return num % 10;
    }
}  
