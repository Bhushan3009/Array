package Arrayprog;

public class Main {
	    public static void main(String[] args) {
	        A input = new A(123, 456);
	        int lD1 = B.fetchLastDigit(input.getNum1());
	        int lD2 = B.fetchLastDigit(input.getNum2());
	        int result = C.multiplyDigits(lD1, lD2);

	        System.out.println("Last Digit 1: " + lD1);
	        System.out.println("Last Digit 2: " + lD2);
	        System.out.println("Result: " + result);
	    }
	}

