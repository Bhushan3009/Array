package Arrayprog;

public class C {
	  public static int multiplyDigits(int d1, int d2) {
	        return d1 * d2;
	    }
	}

