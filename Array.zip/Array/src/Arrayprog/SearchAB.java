package Arrayprog;

public class SearchAB {
public static void main (String args[]) {
	int[] a={10,20,30,40,50};
	boolean isfound=false;
	int Searchno=60;
	for(int i=0;i<a.length;i++) {
		if(a[i]==Searchno) {
			isfound=true;
			break;
		}
	}
	if(isfound==true) {
		System.out.print("element found");
	}
	else {
		System.out.println("element not found");
	}
}
}
