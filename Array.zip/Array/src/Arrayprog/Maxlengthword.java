package Arrayprog;

public class Maxlengthword {
	    public static void main(String[] args) {
	        String s = "“It is a long established fact that a reader will be distracted by the readable content of\r\n"
	        		+ "a page when looking at its layout. The point of using Lorem Ipsum is that it has a\r\n"
	        		+ "more-or-less normal distributionqqqqqqqqqqqqqqqqqqq of letters, as opposed to using\r\n"
	        		+ "'Content here, content here', making it look like readable English”\r\n"
	        		+ "";

	        String[] words = s.split(" "); // Splitting the string into words

	        String maxLengthWord = "";
	        int maxLength = 0;

	        for (String word : words) {
	            // Removing any leading or trailing spaces
	            word = word.trim();

	            if (word.length() > maxLength) {
	                maxLength = word.length();
	                maxLengthWord = word;
	            }
	        }

	        System.out.println("Word with maximum length: " + maxLengthWord);
	    }
	}


