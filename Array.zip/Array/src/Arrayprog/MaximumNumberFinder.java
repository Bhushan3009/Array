package Arrayprog;

public class MaximumNumberFinder {
	    public static int findMaximumNumber(Object[] array) {
	        int maxNumber = Integer.MIN_VALUE;

	        for (Object element : array) {
	            if (element instanceof Object[]) {
	                int subArrayMax = findMaximumNumber((Object[]) element);
	                if (subArrayMax > maxNumber) {
	                    maxNumber = subArrayMax;
	                }
	            } else {
	                int number = (int) element;
	                if (number > maxNumber) {
	                    maxNumber = number;
	                }
	            }
	        }

	        return maxNumber;
	    }

	    public static void main(String[] args) {
	        Object[] array = {2, 4, 10, new Object[]{12, 4, new Object[]{100, 99}, 4}, new Object[]{3, 2, 99}, 0};
	        int maxNumber = findMaximumNumber(array);
	        System.out.println("Maximum number: " + maxNumber);
	    }
	}



