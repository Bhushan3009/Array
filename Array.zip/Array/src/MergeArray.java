import java.util.Arrays;
public class MergeArray {
	

	
	    public static void main(String[] args) {
	        int[] array1 = {5, 9, 12, 18};
	        int[] array2 = {3, 7, 10, 15, 20};

	        int[] mergedArray = mergeArraysDescending(array1, array2);
	        
	        System.out.println("Merged array in descending order: " + Arrays.toString(mergedArray));
	    }

	    public static int[] mergeArraysDescending(int[] array1, int[] array2) {
	        int[] mergedArray = new int[array1.length + array2.length];
	        int i = 0, j = 0, k = 0;

	        // Merge the arrays while maintaining descending order
	        while (i < array1.length && j < array2.length) {
	            if (array1[i] > array2[j]) {
	                mergedArray[k++] = array1[i++];
	            } else {
	                mergedArray[k++] = array2[j++];
	            }
	        }

	        // Add remaining elements from array1, if any
	        while (i < array1.length) {
	            mergedArray[k++] = array1[i++];
	        }

	        // Add remaining elements from array2, if any
	        while (j < array2.length) {
	            mergedArray[k++] = array2[j++];
	        }

	        // Reverse the merged array to obtain descending order
	        reverseArray(mergedArray);

	        return mergedArray;
	    }

	    public static void reverseArray(int[] array) {
	        int left = 0;
	        int right = array.length - 1;

	        while (left < right) {
	            int temp = array[left];
	            array[left] = array[right];
	            array[right] = temp;

	            left++;
	            right--;
	        }
	    }
	}


