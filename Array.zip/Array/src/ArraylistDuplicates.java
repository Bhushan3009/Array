import java.util.ArrayList;
	import java.util.Arrays;
public class ArraylistDuplicates {


	
	    public static void main(String[] args) {
	        String[] array1 = {"Java", "By", "Kiran", "for", "IT-NonIT"};
	        String[] array2 = {"Java", "Experienced", "By"};
	        
	        ArrayList<String> commonElements = findCommonElements(array1, array2);
	        
	        System.out.println("Common Elements: " + commonElements);
	    }
	    
	    public static ArrayList<String> findCommonElements(String[] array1, String[] array2) {
	        ArrayList<String> commonElements = new ArrayList<>();
	        
	        // Convert arrays to ArrayLists for easier manipulation
	        ArrayList<String> list1 = new ArrayList<>(Arrays.asList(array1));
	        ArrayList<String> list2 = new ArrayList<>(Arrays.asList(array2));
	        
	        // Iterate over elements in list1
	        for (String element : list1) {
	            // Check if the element is present in list2
	            if (list2.contains(element)) {
	                commonElements.add(element);
	            }
	        }
	        
	        return commonElements;
	    }
	}


